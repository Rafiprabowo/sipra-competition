<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.peserta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid" style="font-size:11px;">
        <div class="card mb-4 bg-white">
            <div class="card-header">
                <h5>Ulasan Tes CBT</h5>
            </div>
            <div class="card-body">
                <h6>Ringkasan Tes</h6>
                <p><strong>Sesi:</strong> <?php echo e($session->nama); ?></p>        
                <p><strong>Waktu Selesai:</strong> <?php echo e($completed_at); ?></p>
                <hr>
                <p>Terima kasih telah mengikuti tes ini.</p>
                <hr>

                <h6>Langkah Selanjutnya</h6>
                <p>Untuk informasi lebih lanjut atau langkah selanjutnya, kunjungi <a href="<?php echo e(route('peserta.dashboard')); ?>">Dashboard Peserta</a> atau hubungi administrator Anda.</p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/peserta/sesi-cbt/review.blade.php ENDPATH**/ ?>