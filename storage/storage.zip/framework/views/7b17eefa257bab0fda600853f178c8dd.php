<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid" style="font-size: 12px;">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Bank Soal Semaphore Morse</li>
            </ol>
        </nav>

        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <h5>Bank Soal Semaphore Morse</h5>
                <div class="d-flex">
                    <!-- Tombol Import Excel -->
                    <button class="btn btn-warning mr-2" data-toggle="modal" data-target="#importModal" style="font-size: 11px;" title="Import Excel">
                        <i class="fas fa-file-excel"></i>
                    </button>
                </div>
            </div>
            <div class="card-body">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="semaphore-tab" data-toggle="tab" href="#semaphore" role="tab" aria-controls="semaphore" aria-selected="true">Semaphore</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="morse-tab" data-toggle="tab" href="#morse" role="tab" aria-controls="morse" aria-selected="false">Morse</a>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="semaphore" role="tabpanel" aria-labelledby="semaphore-tab">
                        <div class="table-responsive mt-3">
                            <table class="table table-bordered text-center" id="semaphoreTable">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kata</th>
                                        <th>Jenis</th>
                                        <th>Gambar</th>
                                        <th>Tingkat Kesulitan</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $sms_questions->where('type', \App\Enums\QuestionType::SEMAPHORE->value); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($question->word); ?></td>
                                            <td>Semaphore</td>
                                            <td>
                                                <div class="d-flex flex-wrap justify-content-center">
                                                    <?php $__currentLoopData = $question->symbols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symbol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="symbol-container text-center" style="margin-right: 10px; margin-bottom: 5px;">
                                                            <img src="<?php echo e(Storage::url($symbol->image)); ?>" alt="<?php echo e($symbol->letter); ?>" class="symbol-image">
                                                            <div><?php echo e($symbol->letter); ?></div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </td>
                                            <td><?php echo e(ucfirst($question->difficulty)); ?></td>
                                            <td class="d-flex justify-content-center">
                                                <a href="<?php echo e(route('soal-sms.edit', $question->id)); ?>" class="btn btn-warning btn-sm mr-1" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deleteModal<?php echo e($question->id); ?>" title="Delete">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="morse" role="tabpanel" aria-labelledby="morse-tab">
                        <div class="table-responsive mt-3">
                            <table class="table table-bordered text-center" id="morseTable">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kata</th>
                                        <th>Jenis</th>
                                        <th>Gambar</th>
                                        <th>Tingkat Kesulitan</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $sms_questions->where('type', \App\Enums\QuestionType::MORSE->value); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($question->word); ?></td>
                                            <td>Morse</td>
                                            <td>
                                                <div class="d-flex flex-wrap justify-content-center">
                                                    <?php $__currentLoopData = $question->symbols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symbol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="symbol-container text-center" style="margin-right: 10px; margin-bottom: 5px;">
                                                            <img src="<?php echo e(Storage::url($symbol->image)); ?>" alt="<?php echo e($symbol->letter); ?>" class="symbol-image">
                                                            <div><?php echo e($symbol->letter); ?></div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </td>
                                            <td><?php echo e(ucfirst($question->difficulty)); ?></td>
                                            <td class="d-flex justify-content-center">
                                                <a href="<?php echo e(route('soal-sms.edit', $question->id)); ?>" class="btn btn-warning btn-sm mr-1" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deleteModal<?php echo e($question->id); ?>" title="Delete">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Import Modal -->
    <div class="modal fade" id="importModal" tabindex="-1" aria-labelledby="importModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="importModalLabel">Import Soal dari Excel</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('import.soal-sms')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="file">Pilih File Excel</label>
                            <input type="file" class="form-control" id="file" name="file" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Import</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Modals -->
    <?php $__currentLoopData = $sms_questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="deleteModal<?php echo e($question->id); ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?php echo e($question->id); ?>" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel<?php echo e($question->id); ?>">Hapus Soal</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        Apakah Anda yakin ingin menghapus soal ini?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <form action="<?php echo e(route('soal-sms.destroy', $question->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Hapus</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('h-script'); ?>
    <style>
        .symbol-image {
    height: 50px;
}

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $('#morseTable').DataTable(); // Inisialisasi DataTables
            $('#semaphoreTable').DataTable(); // Inisialisasi DataTables
            $('[data-toggle="tooltip"]').tooltip(); // Inisialisasi Tooltip
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/admin/bank-soal/sms/index.blade.php ENDPATH**/ ?>