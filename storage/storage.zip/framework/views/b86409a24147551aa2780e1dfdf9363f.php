<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid" style="font-size: 12px;">

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Sesi Computer Based Test</li>
            </ol>
        </nav>
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert"><?php echo e(session('error')); ?></div>
        <?php endif; ?>
        
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <h5 class="m-0 font-weight-bold text-primary" style="font-size: 16px;">Sesi Computer Based Test</h5>
                <a href="<?php echo e(route('sesi-cbt.create')); ?>" class="btn btn-primary" style="font-size: 11px;" title="Tambah">
                    <i class="fas fa-plus"></i>
                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered text-center" id="dataTable">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Waktu Mulai</th>
                                <th>Waktu Selesai</th>
                                <th>Durasi</th>
                                <th>Status</th>
                                <th>Mata Lomba</th>
                                <th>Jumlah Soal</th>
                                <th>Jenis Soal</th> <!-- New column for question types -->
                                <th>Kode Akses</th>                                    
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($session->nama); ?></td>
                                    <td>
                                        <span class="badge badge-info"><?php echo e($session->waktu_mulai); ?></span>
                                    </td>
                                    <td>
                                        <span class="badge badge-info"><?php echo e($session->waktu_selesai); ?></span>
                                    </td>                                    
                                    <td><?php echo e($session->durasi); ?> Menit</td>  
                                    <td>
                                        <?php if($session->status == 'draft'): ?>
                                            <span class="badge badge-danger">Ditutup</span>
                                        <?php elseif($session->status == 'active'): ?>
                                            <span class="badge badge-success">Dibuka</span>
                                        <?php else: ?>
                                            <span class="badge badge-info">Selesai</span>
                                        <?php endif; ?>
                                    </td>                                       
                                    <td><?php echo e($session->mataLomba->nama); ?></td>
                                    <td><?php echo e($session->jumlah_soal); ?></td>
                                    <td>
                                        <!-- Display question types and counts -->
                                        <?php $__currentLoopData = $session->questionConfigurations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $config): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div><?php echo e($config->question_type); ?></div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td ><?php echo e($session->kode_akses); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('sesi-peserta.index', $session->id)); ?>" class="btn btn-info btn-sm" data-toggle="tooltip" title="Lihat Peserta">
                                            <i class="fas fa-users"></i>
                                        </a>
                                        <a href="<?php echo e(route('sesi-cbt.edit', $session->id)); ?>" class="btn btn-warning btn-sm" data-toggle="tooltip" title="Edit Sesi">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="<?php echo e(route('sesi-soal.index', ['id' => $session->id])); ?>" class="btn btn-primary btn-sm" data-toggle="tooltip" title="Lihat Soal">
                                            <i class="fas fa-question-circle"></i>
                                        </a>
                                        <form action="<?php echo e(route('sesi-cbt.destroy', $session->id)); ?>" method="POST" style="display:inline-block;" onsubmit="return confirm('Apakah Anda yakin ingin menghapus sesi ini?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm" data-toggle="tooltip" title="Hapus Sesi">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            $('#dataTable').DataTable({
                pageLength: 10,
                responsive: true,
                searching: true,
                ordering: true,
            });
        });
    </script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/admin/sesi-cbt/index.blade.php ENDPATH**/ ?>