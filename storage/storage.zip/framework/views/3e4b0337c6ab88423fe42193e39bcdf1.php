<!-- Template PDF -->
<!DOCTYPE html>
<html>
<head>
    <title>Penilaian Lomba</title>
    <style>
        .logo-left {
            float: left;
            width: 50px;
        }
        .logo-right {
            float: right;
            width: 50px;
        }
        h2 {
            font-size: 18px; /* Sesuaikan ukuran font */
            margin: 0;
        }
        h3 {
            font-size: 16px; /* Sesuaikan ukuran font */
            margin: 0;
        }
        h1 {
            font-size: 20px; /* Sesuaikan ukuran font */
            margin: 0;
        }
        p {
            font-size: 14px; /* Sesuaikan ukuran font */
            margin: 0;
        }
        hr {
            border: 3px solid black;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="kop-surat" style="text-align: center;">
        <table>
            <tr>
                <td><img src="<?php echo e($base64LogoKiri); ?>" alt="Logo Kiri" class="kiri" width="70" height="70"></td>
                <td class="center-text" style="text-align: center; align-items: center; padding-left: 50px; padding-right: 50px;">
                    <h2>GERAKAN PRAMUKA</h2>
                    <h3>GUGUS DEPAN KOTA MALANG 04571-04572</h3>
                    <h1>PANGKALAN ARVEGATU SMPN 4 MALANG</h1>
                    <p>Jalan Veteran 37 Malang 65145 telepon (0341) 551289 Fax. (0341) 574062</p>
                </td>
                <td><img src="<?php echo e($base64LogoKanan); ?>" alt="Logo Kanan" class="kanan" width="90" height="90"></td>
            </tr>
        </table>
        <hr style="border: 2px solid black; clear: both;">
    </div>

    <?php if(isset($tab) && ($tab == 'putra' || $tab == 'putri')): ?>
        <?php if($mata_lomba->nama == 'PIONERING'): ?>
            <h3 style="text-align: center; padding-top: 3%; padding-bottom: 3%;">Hasil Lomba Pionering <?php echo e(ucfirst($tab)); ?> LOGIKA 2025</h3>
        <?php elseif($mata_lomba->nama == 'KARIKATUR'): ?>
            <h3 style="text-align: center; padding-top: 3%; padding-bottom: 3%;">Hasil Lomba Karikatur <?php echo e(ucfirst($tab)); ?> LOGIKA 2025</h3>
        <?php elseif($mata_lomba->nama == 'DUTA LOGIKA'): ?>
            <h3 style="text-align: center; padding-top: 3%; padding-bottom: 3%;">Hasil Lomba Duta Logika <?php echo e(ucfirst($tab)); ?> LOGIKA 2025</h3>
        <?php elseif($mata_lomba->nama == 'LKFBB'): ?>
            <h3 style="text-align: center; padding-top: 3%; padding-bottom: 3%;">Hasil Lomba LKFBB <?php echo e(ucfirst($tab)); ?> LOGIKA 2025</h3>
        <?php endif; ?>
        <table border="1" cellpadding="5" cellspacing="0" style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Peserta</th>
                    <th>Regu</th>
                    <th>Pangkalan</th>
                    <th>Jenis Kelamin</th>
                    <th>Nilai Akhir</th>
                    <th>Rangking</th>
                </tr>
            </thead>
            <tbody>
                <?php if($mata_lomba->nama == 'PIONERING'): ?>
                <?php $__currentLoopData = ${$tab}; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($peserta->penilaian_pionering->rangking == 'Juara 1' || $peserta->penilaian_pionering->rangking == 'Juara 2' || $peserta->penilaian_pionering->rangking == 'Juara 3'): ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($peserta->nama); ?></td>
                        <td><?php echo e($peserta->regu_pembina->nama_regu); ?></td>
                        <td><?php echo e($peserta->regu_pembina->pembina->pangkalan); ?></td>
                        <td><?php echo e($peserta->jenis_kelamin); ?></td>
                        <td><?php echo e($peserta->highest_total_nilai); ?></td>
                        <td><?php echo e($peserta->penilaian_pionering->rangking); ?></td>
                    </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <br>
                <div class="footer" style="text-align: left; position: absolute; left: 0;">
                    <p><br></p>
                    <span style="text-align: left;">Ketua Pelaksana</span>
                    <p style="margin-top: 70%;">
                        <?php $__currentLoopData = $ketuaPelaksanas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ketua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($ketua->username); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                </div> 
                <div class="footer" style="text-align: right; position: absolute; right: 0;">
                    <p>Malang, <?php echo e($peserta->penilaian_pionering->first()->created_at->format('d F Y')); ?></p>
                    <span style="text-align: right; padding-left:30%;">Juri Lomba</span>
                    <p style="margin-top: 60%;"><?php echo e($peserta->penilaian_pionering->juri->nama); ?></p>
                </div>    

                <?php elseif($mata_lomba->nama == 'KARIKATUR'): ?>
                <?php $__currentLoopData = ${$tab}; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($peserta->penilaian_karikatur->rangking == 'Juara 1' || $peserta->penilaian_karikatur->rangking == 'Juara 2' || $peserta->penilaian_karikatur->rangking == 'Juara 3'): ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($peserta->nama); ?></td>
                        <td><?php echo e($peserta->regu_pembina->nama_regu); ?></td>
                        <td><?php echo e($peserta->regu_pembina->pembina->pangkalan); ?></td>
                        <td><?php echo e($peserta->jenis_kelamin); ?></td>
                        <td><?php echo e($peserta->highest_total_nilai); ?></td>
                        <td><?php echo e($peserta->penilaian_karikatur->rangking); ?></td>
                    </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br>
                    <div class="footer" style="text-align: left; position: absolute; left: 0;">
                        <p><br></p>
                        <span style="text-align: left;">Ketua Pelaksana</span>
                        <p style="margin-top: 70%;">
                            <?php $__currentLoopData = $ketuaPelaksanas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ketua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($ketua->username); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>
                    </div> 
                    <div class="footer" style="text-align: right; position: absolute; right: 0;">
                        <p>Malang, <?php echo e($peserta->penilaian_karikatur->first()->created_at->format('d F Y')); ?></p>
                        <span style="text-align: right; padding-left:30%;">Juri Lomba</span>
                        <p style="margin-top: 60%;"><?php echo e($peserta->penilaian_karikatur->juri->nama); ?></p>
                    </div>                  

                <?php elseif($mata_lomba->nama == 'DUTA LOGIKA'): ?>
                <?php $__currentLoopData = ${$tab}; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($peserta->penilaian_duta_logika->rangking == 'Juara 1' || $peserta->penilaian_duta_logika->rangking == 'Juara 2' || $peserta->penilaian_duta_logika->rangking == 'Juara 3'): ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($peserta->nama); ?></td>
                        <td><?php echo e($peserta->regu_pembina->nama_regu); ?></td>
                        <td><?php echo e($peserta->regu_pembina->pembina->pangkalan); ?></td>
                        <td><?php echo e($peserta->jenis_kelamin); ?></td>
                        <td><?php echo e($peserta->highest_total_nilai); ?></td>
                        <td><?php echo e($peserta->penilaian_duta_logika->rangking); ?></td>
                    </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <br>
                <div class="footer" style="text-align: left; position: absolute; left: 0;">
                    <p><br></p>
                    <span style="text-align: left;">Ketua Pelaksana</span>
                    <p style="margin-top: 70%;">
                        <?php $__currentLoopData = $ketuaPelaksanas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ketua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($ketua->username); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                </div> 
                <div class="footer" style="text-align: right; position: absolute; right: 0;">
                    <p>Malang, <?php echo e($peserta->penilaian_duta_logika->first()->created_at->format('d F Y')); ?></p>
                    <span style="text-align: right; padding-left:30%;">Juri Lomba</span>
                    <p style="margin-top: 60%;"><?php echo e($peserta->penilaian_duta_logika->juri->nama); ?></p>
                </div>    

                <?php elseif($mata_lomba->nama == 'LKFBB'): ?>
                <?php $__currentLoopData = ${$tab}; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($peserta->penilaian_lkfbb->rangking == 'Juara 1' || $peserta->penilaian_lkfbb->rangking == 'Juara 2' || $peserta->penilaian_lkfbb->rangking == 'Juara 3'): ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($peserta->nama); ?></td>
                        <td><?php echo e($peserta->regu_pembina->nama_regu); ?></td>
                        <td><?php echo e($peserta->regu_pembina->pembina->pangkalan); ?></td>
                        <td><?php echo e($peserta->jenis_kelamin); ?></td>
                        <td><?php echo e($peserta->highest_total_nilai); ?></td>
                        <td><?php echo e($peserta->penilaian_lkfbb->rangking); ?></td>
                    </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <br>
                <div class="footer" style="text-align: left; position: absolute; left: 0;">
                    <p><br></p>
                    <span style="text-align: left;">Ketua Pelaksana</span>
                    <p style="margin-top: 70%;">
                        <?php $__currentLoopData = $ketuaPelaksanas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ketua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($ketua->username); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                </div> 
                <div class="footer" style="text-align: right; position: absolute; right: 0;">
                    <p>Malang, <?php echo e($peserta->penilaian_lkfbb->first()->created_at->format('d F Y')); ?></p>
                    <span style="text-align: right; padding-left:30%;">Juri Lomba</span>
                    <p style="margin-top: 60%;"><?php echo e($peserta->penilaian_lkfbb->juri->nama); ?></p>
                </div>    
                <?php endif; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <?php if(isset($tab) && ($tab == 'penilaian_foto')): ?>
        <?php if($mata_lomba->nama == 'FOTO'): ?>
            <h3 style="text-align: center; padding-top: 3%; padding-bottom: 3%;">Hasil Lomba Foto LOGIKA 2025</h3>
        <?php endif; ?>
        <table border="1" cellpadding="5" cellspacing="0" style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Peserta</th>
                    <th>Regu</th>
                    <th>Pangkalan</th>
                    <th>Nilai Akhir</th>
                    <th>Rangking</th>
                </tr>
            </thead>
            <tbody>
                <?php if($mata_lomba->nama == 'FOTO'): ?>
                <?php $__currentLoopData = $penilaianFotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $penilaian_foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($penilaian_foto->rangking == 'Juara 1' || $penilaian_foto->rangking == 'Juara 2' || $penilaian_foto->rangking == 'Juara 3'): ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($penilaian_foto->juri->nama); ?></td>
                        <td><?php echo e($penilaian_foto->pembina->nama); ?></td>
                        <td><?php echo e($penilaian_foto->pembina->pangkalan); ?></td>
                        <td><?php echo e($penilaian_foto->total_nilai); ?></td>
                        <td><?php echo e($penilaian_foto->rangking); ?></td>
                    </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
        <br>
        <div class="footer" style="text-align: left; position: absolute; left: 0;">
            <p><br></p>
            <span style="text-align: left;">Ketua Pelaksana</span>
            <p style="margin-top: 70%;">
                <?php $__currentLoopData = $ketuaPelaksanas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ketua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($ketua->username); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
        </div> 
        <div class="footer" style="text-align: right; position: absolute; right: 0;">
            <p>Malang, <?php echo e($penilaian_foto->first()->created_at->format('d F Y')); ?></p>
            <span style="text-align: right; padding-left:30%;">Juri Lomba</span>
            <p style="margin-top: 60%;"><?php echo e($penilaian_foto->juri->nama); ?></p>
        </div>    
    <?php endif; ?>

    <?php if(isset($tab) && ($tab == 'penilaian_dutaLogika')): ?>
        <?php if($mata_lomba->nama == 'DUTA LOGIKA'): ?>
            <h3 style="text-align: center; padding-top: 3%; padding-bottom: 3%;">Hasil Lomba Duta Logika LOGIKA 2025</h3>
        <?php endif; ?>
        <table border="1" cellpadding="5" cellspacing="0" style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Peserta</th>
                    <th>Regu</th>
                    <th>Pangkalan</th>
                    <th>Jenis Kelamin</th>
                    <th>Nilai akhir</th>
                    <th>Rangking</th>
                </tr>
            </thead>
            <tbody>
                <?php if($mata_lomba->nama == 'DUTA LOGIKA'): ?>
                <?php $__currentLoopData = $peserta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->penilaian_duta_logika->rangking == 'Juara 1' || $item->penilaian_duta_logika->rangking == 'Juara 2' || $item->penilaian_duta_logika->rangking == 'Juara 3'): ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($item->nama); ?></td>
                        <td><?php echo e($item->regu_pembina->nama_regu); ?></td>
                        <td><?php echo e($item->regu_pembina->pembina->pangkalan); ?></td>
                        <td><?php echo e($item->jenis_kelamin); ?></td>
                        <td><?php echo e($item->highest_total_nilai); ?></td>
                        <td><?php echo e($item->penilaian_duta_logika->rangking); ?></td>
                    </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
        <br>
        <div class="footer" style="text-align: left; position: absolute; left: 0;">
            <p><br></p>
            <span style="text-align: left;">Ketua Pelaksana</span>
            <p style="margin-top: 70%;">
                <?php $__currentLoopData = $ketuaPelaksanas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ketua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($ketua->username); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
        </div> 
        <div class="footer" style="text-align: right; position: absolute; right: 0;">
            <p>Malang, <?php echo e($item->penilaian_duta_logika->first()->created_at->format('d F Y')); ?></p>
            <span style="text-align: right; padding-left:30%;">Juri Lomba</span>
            <p style="margin-top: 60%;"><?php echo e($item->penilaian_duta_logika->juri->nama); ?></p>
        </div>    
    <?php endif; ?>

    <?php if(isset($tab) && ($tab == 'penilaian_vidio')): ?>
        <?php if($mata_lomba->nama == 'VIDIO'): ?>
            <h3 style="text-align: center; padding-top: 3%; padding-bottom: 3%;">Hasil Lomba Vidio LOGIKA 2025</h3>
        <?php endif; ?>
        <table border="1" cellpadding="5" cellspacing="0" style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Peserta</th>
                    <th>Regu</th>
                    <th>Pangkalan</th>
                    <th>Nilai Akhir</th>
                    <th>Rangking</th>
                </tr>
            </thead>
            <tbody>
                <?php if($mata_lomba->nama == 'VIDIO'): ?>
                <?php $__currentLoopData = $penilaianVidios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $penilaian_vidio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($penilaian_vidio->rangking == 'Juara 1' || $penilaian_vidio->rangking == 'Juara 2' || $penilaian_vidio->rangking == 'Juara 3'): ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($penilaian_vidio->juri->nama); ?></td>
                        <td><?php echo e($penilaian_vidio->pembina->nama); ?></td>
                        <td><?php echo e($penilaian_vidio->pembina->pangkalan); ?></td>
                        <td><?php echo e($penilaian_vidio->total_nilai); ?></td>
                        <td><?php echo e($penilaian_vidio->rangking); ?></td>
                    </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
        <br>
        <div class="footer" style="text-align: left; position: absolute; left: 0;">
            <p><br></p>
            <span style="text-align: left;">Ketua Pelaksana</span>
            <p style="margin-top: 70%;">
                <?php $__currentLoopData = $ketuaPelaksanas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ketua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($ketua->username); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
        </div> 
        <div class="footer" style="text-align: right; position: absolute; right: 0;">
            <p>Malang, <?php echo e($penilaian_vidio->first()->created_at->format('d F Y')); ?></p>
            <span style="text-align: right; padding-left:30%;">Juri Lomba</span>
            <p style="margin-top: 60%;"><?php echo e($penilaian_vidio->juri->nama); ?></p>
        </div>    
    <?php endif; ?>
</body>
</html><?php /**PATH D:\sipra-competition\resources\views/admin/hasil_nilai/template.blade.php ENDPATH**/ ?>