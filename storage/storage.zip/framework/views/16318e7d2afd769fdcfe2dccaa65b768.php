<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.peserta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid d-flex justify-content-center" style="font-size:11px;">
    <div class="row w-100">
        <!-- Question Content -->
        <div class="col-md-8">
            <div class="card mb-4" style="background-color: #ffffff; border-radius: 0; border: 1px solid #ddd;">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span>Soal Nomor <?php echo e($question_number); ?></span>
                    <span><?php echo e($session->nama); ?></span>
                </div>
                <div class="card-body">
                    <div id="question">
                        <p><strong><?php echo e($tpk_question->question_text); ?></strong></p>
                        <?php if($tpk_question->question_image): ?>
                        <div class="mb-3">
                            <img src="<?php echo e(Storage::url($tpk_question->question_image)); ?>" alt="Question Image" class="img-fluid">
                        </div>
                        <?php endif; ?>
                        <div class="form-group">
                            <?php $__currentLoopData = ['a', 'b', 'c', 'd']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="custom-control custom-radio mb-3">
                                <input type="radio" id="answer_<?php echo e($option); ?>" name="answer" class="custom-control-input"
                                    value="<?php echo e($option); ?>" <?php echo e($answer == $option ? 'checked' : ''); ?>>
                                <label class="custom-control-label d-flex align-items-center" for="answer_<?php echo e($option); ?>">
                                    <span class="mr-2 font-weight-bold"><?php echo e(strtoupper($option)); ?>.</span>
                                    <span><?php echo e($tpk_question->{'answer_' . $option}); ?></span>
                                </label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="card-footer d-flex justify-content-between">
                    <button id="prev-question" class="btn btn-secondary">Soal Sebelumnya</button>
                    <button id="next-question" class="btn btn-primary">Soal Selanjutnya</button>
                </div>
            </div>
        </div>

        <!-- Navigation Content -->
        <div class="col-md-4">
            <div class="card" style="background-color: #ffffff; border-radius: 0; border: 1px solid #ddd;">
                <div class="card-header">
                    <h5>Nomor Soal</h5>
                </div>
                <div class="card-body">
                    <div class="number-navigation d-flex flex-wrap justify-content-start">
                        <?php
                        $tpk_questions = $session->tpk_questions;
                        ?>
                        <?php $__currentLoopData = $tpk_questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $answered = \App\Models\TpkAnswer::where('peserta_id', Auth::user()->peserta->id)
                            ->where('cbt_session_id', $session->id)
                            ->where('tpk_question_id', $question->id)
                            ->exists();
                        ?>
                        <a href="<?php echo e(route('start.cbt', ['session_id' => $session->id, 'question_number' => $loop->iteration])); ?>"
                            class="btn btn-question <?php echo e($answered ? 'answered' : 'not-answered'); ?>"
                            id="btn-question-<?php echo e($question->id); ?>">
                            <?php echo e($loop->iteration); ?>

                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="card-footer d-flex justify-content-between">
                    <button id="end-test" class="btn btn-danger">Akhiri Tes</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('h-script'); ?>
<style>
    .number-navigation {
        display: flex;
        flex-wrap: wrap;
        justify-content: start;
        gap: 10px;
    }

    .number-navigation .btn-question {
        width: 50px;
        text-align: center;
        font-weight: bold;
        border-radius: 10px;
    }

    .not-answered {
        background-color: #ffffff;
        color: black;
        border: 1px solid #ddd;
    }

    .answered {
        background-color: #28a745;
        color: white;
        border: 1px solid #28a745;
    }

    @media (max-width: 576px) {
        .number-navigation .btn-question {
            width: 40px;
            height: 40px;
            line-height: 40px;
            font-size: 12px;
        }
    }

    .card {
        border-radius: 0;
    }

    #question {
        padding: 20px;
        background-color: #f8f9fa;
    }

    #question p {
        font-size: 18px;
        line-height: 1.5;
    }

    #question .form-group {
        margin-top: 15px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
$(document).ready(function() {
    $('input[name="answer"]').change(function() {
        let selectedAnswer = $(this).val();
        let sessionId = "<?php echo e($session->id); ?>";
        let questionId = "<?php echo e($tpk_question->id); ?>";

        $.ajax({
            url: "<?php echo e(route('answer.cbt', ['session_id' => $session->id, 'question_number' => $question_number])); ?>",
            method: "POST",
            data: {
                _token: "<?php echo e(csrf_token()); ?>",
                answer: selectedAnswer,
                question_id: questionId
            },
            success: function(response) {
                console.log('Response:', response);
                $(`#btn-question-${questionId}`).addClass('answered').removeClass('not-answered');
            },
            error: function(xhr) {
                console.error('Error:', xhr.responseText);
            }
        });
    });

    if (parseInt("<?php echo e($question_number); ?>") <= 1) {
        $('#prev-question').attr('disabled', true);
    }

    if (parseInt("<?php echo e($question_number); ?>") >= "<?php echo e($session->tpk_questions->count()); ?>") {
        $('#next-question').attr('disabled', true);
    }

    $('#next-question').click(function() {
        let nextQuestionNumber = parseInt("<?php echo e($question_number); ?>") + 1;
        window.location.href = "/peserta/cbt/" + "<?php echo e($session->id); ?>" + "/start/" + nextQuestionNumber;
    });

    $('#prev-question').click(function() {
        let prevQuestionNumber = parseInt("<?php echo e($question_number); ?>") - 1;
        if (prevQuestionNumber > 0) {
            window.location.href = "/peserta/cbt/" + "<?php echo e($session->id); ?>" + "/start/" + prevQuestionNumber;
        }
    });

    $('#end-test').click(function() {
        if (confirm('Apakah Anda yakin ingin mengakhiri tes?')) {
            window.location.href = "<?php echo e(route('end.cbt', ['session_id' => $session->id])); ?>";
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/peserta/sesi-cbt/tpk/exam.blade.php ENDPATH**/ ?>