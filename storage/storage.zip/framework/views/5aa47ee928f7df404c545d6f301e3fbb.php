<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.juri', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-sm-12 ms-2 me-2 mt-4" style="font-size: 11px;">
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert"> <?php echo e(session('success')); ?> </div>
        <?php endif; ?>
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-primary" style="font-size: 11px;">Data Penilaian Foto</h6>
                <a href="<?php echo e(route('penilaian-foto.create')); ?>" class="btn btn-primary btn-md" title="Tambah" style="font-size: 11px;">
                    <i class="fas fa-plus"></i>
                </a>
            </div>

            <div class="card-body">
                <!-- Tabel Penilaian Foto -->
                <div class="mb-5">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="penilaianFotoTable" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Juri</th>
                                <th>Nama Pembina</th>
                                <th>Total Nilai</th>
                                <th>Aksi</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $penilaianFotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $penilaianFoto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($penilaianFoto->juri->nama); ?></td>
                                    <td><?php echo e($penilaianFoto->pembina->nama); ?></td>
                                    <td><?php echo e($penilaianFoto->total_nilai); ?></td>
                                    <td>
                                        
                                    
                                        <!-- Form Hapus -->
                                        <form action="<?php echo e(route('penilaian-foto.destroy', $penilaianFoto->id)); ?>" method="POST" style="display: inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus penilaian ini?')" title="Hapus">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>                                  
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Initialize DataTable with Export buttons
            $('#penilaianFotoTable').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    {
                        extend: 'excelHtml5',
                        text: '<i class="fas fa-file-excel"></i> Export Excel',
                        titleAttr: 'Export to Excel'
                    },
                    {
                        extend: 'pdfHtml5',
                        text: '<i class="fas fa-file-pdf"></i> Export PDF',
                        titleAttr: 'Export to PDF'
                    }
                ],
                pageLength: 5, // Set number of rows per page
                responsive: true
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/juri/penilaian_foto/index.blade.php ENDPATH**/ ?>