<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Form Edit Konfigurasi Soal</h6>
                <a href="<?php echo e(route('cbt-session-question-configurations.index')); ?>" class="btn btn-secondary btn-sm">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('cbt-session-question-configurations.update', $configuration->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="form-group">
                        <label for="cbt_session_id">Sesi CBT</label>
                        <select class="form-control" name="cbt_session_id" id="cbt_session_id" style="font-size: 11px;" required>
                            <option value="">--Pilih Sesi CBT--</option>
                            <?php $__currentLoopData = $cbtSessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($session->id); ?>" 
                                    <?php echo e($configuration->cbt_session_id == $session->id ? 'selected' : ''); ?>>
                                    <?php echo e($session->nama); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['cbt_session_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="question_type">Jenis Soal</label>
                        <select class="form-control" name="question_type" id="question_type" style="font-size: 11px;" required>
                            <option value="<?php echo e(\App\Enums\QuestionType::MORSE->value); ?>" 
                                <?php echo e($configuration->question_type == \App\Enums\QuestionType::MORSE->value ? 'selected' : ''); ?>>
                                Morse
                            </option>
                            <option value="<?php echo e(\App\Enums\QuestionType::SEMAPHORE->value); ?>" 
                                <?php echo e($configuration->question_type == \App\Enums\QuestionType::SEMAPHORE->value ? 'selected' : ''); ?>>
                                Semaphore
                            </option>
                            <option value="<?php echo e(\App\Enums\QuestionType::PK->value); ?>" 
                                <?php echo e($configuration->question_type == \App\Enums\QuestionType::PK->value ? 'selected' : ''); ?>>
                                Pengetahuan Kepramukaan
                            </option>
                        </select>
                        <?php $__errorArgs = ['question_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="question_count">Jumlah Soal</label>
                        <input type="number" class="form-control" name="question_count" id="question_count" 
                            value="<?php echo e(old('question_count', $configuration->question_count)); ?>" style="font-size: 11px;" required>
                        <?php $__errorArgs = ['question_count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="d-flex">
                        <button type="submit" class="btn btn-primary" style="font-size: 11px;" title="Simpan">
                            <i class="fas fa-save"></i> Simpan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/admin/pengaturan-soal/edit.blade.php ENDPATH**/ ?>