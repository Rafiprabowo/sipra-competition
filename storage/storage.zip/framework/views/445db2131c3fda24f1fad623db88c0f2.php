<!-- Pastikan jQuery dimuat terlebih dahulu -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>



<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.juri', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container" style="font-size: 11px;">
    <h2 class="mb-4" style="font-size: 11px;">Form Penilaian Foto</h2>
    <!-- Form Penilaian -->
    <form action="<?php echo e(route('penilaian-foto.store')); ?>" method="POST" id="penilaianForm">
        <?php echo csrf_field(); ?>
        <!-- Filter -->
        <div class="mb-4">
            <!-- Filter Pangkalan -->
            <div class="mb-3">
                <label for="filter-pangkalan" class="form-label">Filter Pangkalan</label>
                <select id="filter-pangkalan" name="pembina_id" class="form-control" style="font-size: 11px;">
                    <option value="">-- Pilih Pangkalan --</option>
                    <?php $__currentLoopData = $pangkalans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pangkalan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($pangkalan->id); ?>"><?php echo e($pangkalan->pangkalan); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- Filter Nama Pembina -->
            <div class="mb-3">
                <label for="pembina" class="form-label">Nama Pembina</label>
                <input type="text" id="nama_pembina" class="form-control" style="font-size: 11px;" readonly>
            </div>
        </div>

        <!-- Daftar kriteria nilai -->
        <input type="hidden" name="mata_lomba_id" value="<?php echo e($mata_lomba->id); ?>">
        <h5 class="mt-4" style="font-size: 11px;">Kriteria Nilai</h5>
        <div id="kriteria-container">
            <?php $__currentLoopData = $bobot_soals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bobot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row align-items-center mb-3">
                <div class="col-md-4">
                    <label class="form-label"><?php echo e($bobot->kriteria_nilai); ?></label>
                    <span>Nilai (0 - <?php echo e($bobot->bobot_soal); ?>)</span>
                </div>
                <div class="col-md-3">
                    <input 
                        type="number" 
                        name="nilai[<?php echo e($bobot->id); ?>]" 
                        class="form-control nilai-input" 
                        placeholder="Masukkan Nilai" 
                        data-max="<?php echo e($bobot->bobot_soal); ?>" 
                        data-kriteria="<?php echo e($bobot->kriteria_nilai); ?>" style="font-size: 11px;"
                        required>
                </div>
            </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Tombol Submit -->
        <div class="mt-4">
            <button type="submit" class="btn btn-primary" style="font-size: 11px;" title="Simpan">
                <i class="fas fa-save"></i>
            </button>
        </div>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    $(document).ready(function () {
        $('#filter-pangkalan').change(function () {
            let pembina_id = $(this).val();
            let url = `/juri/foto/${pembina_id}`;
            
            $.ajax({
                url: url,
                method: 'GET',
                success: function(response) {
                    console.log(response.data.nama)
                    $('#nama_pembina').val(response.data.nama)
                },
                error: function() {
                    alert('Terjadi kesalahan saat mengambil data pembina.');
                },
            });
        });
    });

    document.addEventListener('DOMContentLoaded', function () {
        const form = document.querySelector('#penilaianForm');

        form.addEventListener('submit', function (event) {
            event.preventDefault(); // Mencegah form terkirim langsung
            const inputs = form.querySelectorAll('.nilai-input');
            let isValid = true;
            let invalidFields = [];

            // Validasi setiap input nilai
            inputs.forEach(input => {
                const maxValue = parseFloat(input.dataset.max); // Nilai maksimal
                const kriteria = input.dataset.kriteria; // Nama kriteria
                const value = parseFloat(input.value);

                if (value < 0 || value > maxValue) {
                    isValid = false;
                    invalidFields.push({ kriteria, maxValue });
                }
            });

            if (!isValid) {
                // Tampilkan pesan error jika ada input yang tidak valid
                Swal.fire({
                    icon: 'error',
                    title: 'Validasi Gagal',
                    html: invalidFields.map(field => 
                        `Nilai untuk kriteria "<strong>${field.kriteria}</strong>" harus berada di antara 0 dan ${field.maxValue}.`
                    ).join('<br>'),
                    confirmButtonColor: '#d33'
                });
            } else {
                // Submit form jika semua input valid
                form.submit();
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/juri/penilaian_foto/create.blade.php ENDPATH**/ ?>