<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container" style="font-size: 11px;">
    <h1 style="font-size: 11px;">Edit Finalisasi</h1>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('finalisasi.update', $finalisasi->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?> <!-- Adding method directive for PUT request -->

        <!-- Pembina Details -->
        <div class="form-group">
            <label for="pembina_nama">Nama Pembina</label>
            <input type="text" class="form-control" id="pembina_nama" style="font-size: 11px;" value="<?php echo e($finalisasi->pembina->nama); ?>" disabled>
        </div>
        <div class="form-group">
            <label for="pembina_pangkalan">Pangkalan</label>
            <input type="text" class="form-control" id="pembina_pangkalan" style="font-size: 11px;" value="<?php echo e($finalisasi->pembina->pangkalan); ?>" disabled>
        </div>

        <!-- Upload Dokumen Details -->
        <h3 style="font-size: 11px;">Dokumen</h3>
        <?php $__currentLoopData = $finalisasi->pembina->upload_dokumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uploadDokumen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title" style="font-size: 11px;"><?php echo e($uploadDokumen->template_dokumen->nama ?? 'Template Tidak Ditemukan'); ?></h5>
                    <p class="card-text"><strong>File:</strong> <a href="<?php echo e(route('viewFile', basename($uploadDokumen->file))); ?>" target="_blank" class="text-info"><i class="fas fa-eye"></i> Lihat</a></p>
                    <div class="form-group">
                        <label for="dokumen_status_<?php echo e($uploadDokumen->id); ?>">Status</label>
                        <select name="dokumen_status[<?php echo e($uploadDokumen->id); ?>]" class="form-control" style="font-size: 11px;">
                            <option value="1" <?php echo e($uploadDokumen->status == 1 ? 'selected' : ''); ?>>Disetujui</option>
                            <option value="0" <?php echo e($uploadDokumen->status == 0 ? 'selected' : ''); ?>>Ditolak</option>
                            <option value="" <?php echo e(is_null($uploadDokumen->status) ? 'selected' : ''); ?>>Menunggu Verifikasi</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="dokumen_keterangan_<?php echo e($uploadDokumen->id); ?>">Keterangan</label>
                        <textarea name="dokumen_keterangan[<?php echo e($uploadDokumen->id); ?>]" class="form-control" style="font-size: 11px;"><?php echo e($uploadDokumen->keterangan); ?></textarea>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <!-- Finalisasi Details -->
        <div class="form-group">
            <label for="status">Status Finalisasi</label>
            <select name="status" id="status" class="form-control" style="font-size: 11px;">
                <option value="1" <?php echo e($finalisasi->status == 1 ? 'selected' : ''); ?>>Lolos Verifikasi</option>
                <option value="0" <?php echo e($finalisasi->status == 0 ? 'selected' : ''); ?>>Tidak Lolos Verifikasi</option>
                <option value="" <?php echo e(is_null($finalisasi->status) ? 'selected' : ''); ?>>Menunggu Verifikasi</option>
            </select>
        </div>
        <div class="form-group">
            <label for="keterangan">Keterangan Finalisasi</label>
            <textarea name="keterangan" id="keterangan" class="form-control" style="font-size: 11px;"><?php echo e($finalisasi->keterangan); ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary mr-2" style="font-size: 11px;" title="Update">
            <i class="fas fa-sync-alt"></i>
        </button>
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-secondary ml-2" title="Kembali" style="font-size: 11px;">
            <i class="fas fa-arrow-left"></i>
        </a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/admin/finalisasi/edit.blade.php ENDPATH**/ ?>