<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-sm-12 ms-2 me-2 mt-4" style="font-size: 11px;">
    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert"> <?php echo e(session('success')); ?> </div>
    <?php endif; ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary" style="font-size: 11px;">Data Lihat Bobot Soal</h6>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" style="text-align: center">
                    <thead>
                        <tr>
                            <th>Mata Lomba</th>
                            <th>Kriteria Nilai</th>
                            <th>Bobot</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $bobot_soals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bobot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($bobot->mata_lomba->nama); ?></td>
                                <td><?php echo e($bobot->kriteria_nilai); ?></td>
                                <td><?php echo e($bobot->bobot_soal); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.bobot-soal.edit', $bobot->id)); ?>" class="btn btn-warning btn-sm mx-3" title="Ubah" style="font-size: 11px;">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.bobot-soal.deleteRow', $bobot->id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('POST'); ?>
                                        <input type="hidden" name="kriteria_nilai" value="<?php echo e($bobot->kriteria_nilai); ?>" style="font-size: 11px;">
                                        <button type="submit" class="btn btn-danger" title="Hapus" style="font-size: 11px;">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="2"><strong>Total Bobot</strong></td>
                            <td colspan="2"><strong><?php echo e($bobot_soals->sum('bobot_soal')); ?></strong></td>
                        </tr>
                    </tfoot>
                </table>            
                <a href="<?php echo e(route('admin.bobot-soal.index')); ?>" class="btn btn-secondary" title="Kembali" style="font-size: 11px;">
                    <i class="fas fa-arrow-left"></i>
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/admin/bobot_soal/show.blade.php ENDPATH**/ ?>