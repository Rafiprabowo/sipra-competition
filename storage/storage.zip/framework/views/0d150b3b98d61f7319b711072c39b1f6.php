<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-sm-12 ms-2 me-2 mt-4">
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert"> <?php echo e(session('success')); ?> </div>
        <?php endif; ?>
        <div class="card shadow mb-4" style="font-size: 11px;">
            <div class="card-header py-3"><h6 class="m-0 font-weight-bold text-primary" style="font-size: 11px;">Form Tambah User</h6></div>
            <div class="card-body">
                <form action="<?php echo e(route('users.store')); ?>" method="POST"> <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" id="username" name="username" style="font-size: 11px;" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" style="font-size: 11px;" required>
                    </div>
                    <div class="form-group">
                        <label for="role">Jenis Akun</label>
                        <select
                            class="form-control" id="role" name="role" style="font-size: 11px;" required>
                            <option value="admin">Admin</option>
                            <option value="pembina">Pembina</option>
                            <option value="peserta">Peserta</option>
                            <option value="juri">Juri</option>
                            <option value="ketua_pelaksana">Ketua Pelaksana</option>
                        </select>
                    </div>

                    <div class="d-flex justify-content-start mt-3">
                        <button type="submit" class="btn btn-primary" style="font-size: 11px;" title="Simpan">
                            <i class="fas fa-save"></i>
                        </button>
                        <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary ml-2" style="font-size: 11px;" title="Kembali">
                            <i class="fas fa-arrow-left"></i>
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/admin/user/create.blade.php ENDPATH**/ ?>