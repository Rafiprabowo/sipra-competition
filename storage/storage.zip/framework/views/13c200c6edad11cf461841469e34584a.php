<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.peserta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid" style="font-size:11px;">
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert"><?php echo e(session('error')); ?></div>
        <?php endif; ?>
        <h5>Mulai Ujian</h5>

        <?php if($sessions->isEmpty()): ?>
            <div class="alert alert-info" role="alert">
                Tidak ada sesi ujian yang tersedia saat ini.
            </div>
        <?php else: ?>
            <div class="table-responsive bg-white p-3 rounded">
                <table class="table table-bordered text-center">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>Waktu Mulai</th>
                            <th>Waktu Selesai</th>
                            <th>Durasi</th>
                            <th>Jumlah Huruf</th>
                            <th>Token</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($session->nama); ?></td>
                                <td><span class="badge badge-info"><?php echo e(\Carbon\Carbon::parse($session->waktu_mulai)->format('d-m-Y H:i')); ?></span></td>
                                <td><span class="badge badge-info"><?php echo e(\Carbon\Carbon::parse($session->waktu_selesai)->format('d-m-Y H:i')); ?></span></td>
                                <td><?php echo e($session->durasi); ?> menit</td>
                                <td><?php echo e($session->jumlah_soal); ?> </td>
                                
                                <td>
                                    <form action="<?php echo e(route('token.cbt', $session->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group mb-0">
                                            <input type="text" class="form-control" id="token_<?php echo e($session->id); ?>" name="token" required>
                                        </div>
                                </td>
                                <td>
                                    <button type="submit" class="btn btn-primary" style="font-size:11px;">Mulai Ujian</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

        <div class="d-flex justify-content-start mt-4">
            <a href="<?php echo e(route('peserta.dashboard')); ?>" class="btn btn-secondary" style="font-size:11px;" title="Kembali">
                <i class="fas fa-arrow-left"></i>
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/peserta/sesi-cbt/sms/index.blade.php ENDPATH**/ ?>