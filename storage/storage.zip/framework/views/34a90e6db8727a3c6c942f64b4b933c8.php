<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-4" style="font-size: 11px;">
        <div class="card">
            <div class="card-header bg-warning text-white d-flex justify-content-between align-items-center">
                <h5 style="font-size: 11px;">Daftar Template Dokumen</h5>
                <!-- Tombol Tambah Dokumen -->
                <a href="<?php echo e(route('dokumen.create')); ?>" class="btn btn-primary" style="font-size: 11px;" title="Tambah">
                    <i class="fa fa-plus"></i>
                </a>
            </div>
            <div class="card-body">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table id="dokumenTable" class="table table-bordered" style="text-align: center">
                        <thead class="thead-light">
                        <tr>
                            <th>No</th>
                            <th>Nama Dokumen</th>
                            <th>Tipe</th>
                            <th>Aksi</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $dokumens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($doc->nama); ?></td>
                                <td><?php echo e($doc->tipe); ?></td>

                                <td>
                                    <a href="<?php echo e(route('downloadTemplate', $doc->id)); ?>" class="btn btn-info btn-sm mr-2" title="Unduh" style="font-size: 11px;">
                                        <i class="fa fa-download"></i>
                                    </a>
                                    <a href="<?php echo e(route('dokumen.edit', $doc->id)); ?>" class="btn btn-warning btn-sm mr-2" style="font-size: 11px;" title="Edit">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('dokumen.destroy', $doc->id)); ?>" method="POST"
                                          style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm"
                                                onclick="return confirm('Apakah Anda yakin?')" style="font-size: 11px;" title="Hapus">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            $('#dokumenTable').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/admin/template-dokumen/index.blade.php ENDPATH**/ ?>