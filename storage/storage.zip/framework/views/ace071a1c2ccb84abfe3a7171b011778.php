<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid" style="font-size: 11px;">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Pertanyaan Semaphore Morse</li>
            </ol>
        </nav>

        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <h5 class="m-0 font-weight-bold text-primary" style="font-size: 16px;">List Pertanyaan Semaphore Morse</h5>
                <a href="<?php echo e(route('sms-questions.create')); ?>" class="btn btn-primary btn-sm" style="font-size: 11px;" title="Tambah">
                    <i class="fas fa-plus"></i>
                </a>
            </div>
            <div class="card-body">
                <table class="table table-bordered table-sm" id="smsQuestionsTable">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Sesi CBT</th>
                            <th>Kata</th>
                            <th>Jenis</th>
                            <th>Gambar Semaphore Morse</th>
                            <th>Kesulitan</th> <!-- Tambahkan kolom untuk difficulty -->
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $smsQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $smsQuestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($smsQuestion->cbtSession ? $smsQuestion->cbtSession->nama : 'N/A'); ?></td>
                                <td><?php echo e($smsQuestion->word); ?></td>
                                <td><?php echo e($smsQuestion->type == \App\Enums\QuestionType::SEMAPHORE->value ? 'Semaphore' : 'Morse'); ?></td>
                                <td>
                                    <div class="d-flex flex-wrap justify-content-start">
                                        <?php $__currentLoopData = $smsQuestion->symbols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symbol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="symbol-container text-center" style="margin-right: 10px; margin-bottom: 5px;">
                                                <img src="<?php echo e(Storage::url($symbol->image)); ?>" alt="<?php echo e($symbol->letter); ?>" class="symbol-image">
                                                <div><?php echo e($symbol->letter); ?></div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </td>
                                <td><?php echo e(ucfirst($smsQuestion->difficulty)); ?></td> <!-- Menampilkan nilai difficulty -->
                                <td>
                                    
                                    <a href="<?php echo e(route('sms-questions.edit', $smsQuestion->id)); ?>" class="btn btn-sm btn-warning mr-2" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('sms-questions.destroy', $smsQuestion->id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger" title="Delete" onclick="return confirm('Are you sure you want to delete this question?')">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('h-script'); ?>
    <style>
        .symbol-image {
            width: auto;  /* Set the width as needed */
            height: 50px; /* Maintain aspect ratio */
            object-fit: contain; /* Prevent image from stretching */
        }

        .symbol-container {
            text-align: center;
        }

        .d-flex {
            flex-wrap: wrap;
            justify-content: flex-start;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('#smsQuestionsTable').DataTable({
            "paging": true,       // Enable pagination
            "searching": true,    // Enable searching
            "ordering": true,     // Enable sorting
            "info": true,         // Display information
            "autoWidth": false    // Disable automatic column width adjustment
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/admin/sms-questions/index.blade.php ENDPATH**/ ?>