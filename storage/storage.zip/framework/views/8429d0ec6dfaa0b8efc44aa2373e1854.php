<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid" style="font-size: 11px;">

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('sesi-cbt.index')); ?>">Sesi Computer Based Test</a></li>
            <li class="breadcrumb-item active" aria-current="page">Soal <?php echo e($session->nama); ?></li>
        </ol>
    </nav>

    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header d-flex justify-content-between">
            <h5 style="font-size: 11px;">Soal <?php echo e($session->nama); ?> Computer Based Test</h5>
    
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered text-center" id="dataTable">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tipe</th>
                            <th>Kata</th>
                            <th>Gambar</th>
                            <th>Tingkat Kesulitan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $iteration = 1; ?>
                        <?php $__currentLoopData = $session->smsQuestions->filter(function($question) {
                            return $question->type == 'SEMAPHORE';
                        }); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($iteration); ?></td>
                                <td><?php echo e($question->type); ?></td>
                                <td><?php echo e($question->word); ?></td>
                                <td>
                                    <div class="d-flex flex-wrap justify-content-start">
                                        <?php $__currentLoopData = $question->symbols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symbol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <div class="symbol-container text-center" style="margin-right: 10px; margin-bottom: 5px; width: 80px;">
                                                <img src="<?php echo e(Storage::url($symbol->image)); ?>" alt="<?php echo e($symbol->letter); ?>" class="symbol-image" style="width: 100%; height: auto; border: 1px solid #ddd; border-radius: 5px;">
                                                <div style="font-size: 10px; margin-top: 5px;"><?php echo e($symbol->letter); ?></div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </td>
                                <td><?php echo e($question->difficulty); ?></td>
                          
                            </tr>
                            <?php $iteration++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php $__currentLoopData = $session->smsQuestions->filter(function($question) {
                            return $question->type == 'MORSE';
                        }); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($iteration); ?></td>
                                <td><?php echo e($question->type); ?></td>
                                <td><?php echo e($question->word); ?></td>
                                <td>
                                    <div class="d-flex flex-wrap justify-content-start">
                                        <?php $__currentLoopData = $question->symbols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symbol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <div class="symbol-container text-center" style="margin-right: 10px; margin-bottom: 5px; width: 80px;">
                                                <img src="<?php echo e(Storage::url($symbol->image)); ?>" alt="<?php echo e($symbol->letter); ?>" class="symbol-image" style="width: 100%; height: auto; border: 1px solid #ddd; border-radius: 5px;">
                                                <div style="font-size: 10px; margin-top: 5px;"><?php echo e($symbol->letter); ?></div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </td>
                                <td><?php echo e($question->difficulty); ?></td>
                          
                            </tr>
                            <?php $iteration++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


</div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        $('#dataTable').DataTable({
            pageLength: 10,
            responsive: true,
            searching: true,
            ordering: true,
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/admin/soal-sms/index.blade.php ENDPATH**/ ?>