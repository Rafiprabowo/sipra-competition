<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-sm-12 ms-2 me-2 mt-2">
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="card shadow mb-4" style="font-size: 11px;">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary" style="font-size: 11px;">Form Tambah Bobot Soal</h6>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.bobot-soal.storeTemporary')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="container-md">
                        <!-- Input Nama -->
                        <div class="form-group">
                            <label for="mata_lomba_id">Nama Mata Lomba</label>
                            <select class="form-control <?php $__errorArgs = ['mata_lomba_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="mata_lomba_id" name="mata_lomba_id" style="font-size: 11px;" required>
                                <option value="">Pilih Mata Lomba</option>
                                <?php $__currentLoopData = $mata_lomba; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mataLomba): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($mataLomba->id); ?>" <?php echo e(old('mata_lomba_id') == $mataLomba->id ? 'selected' : ''); ?>><?php echo e($mataLomba->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['mata_lomba_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="form-group">
                            <label for="kriteria_nilai">Kriteria Nilai</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['kriteria_nilai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="kriteria_nilai" name="kriteria_nilai" value="<?php echo e(old('kriteria_nilai')); ?>" style="font-size: 11px;" required>
                            <?php $__errorArgs = ['kriteria_nilai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="form-group">
                            <label for="bobot_soal">Bobot Soal</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['bobot_soal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="bobot_soal" name="bobot_soal" value="<?php echo e(old('bobot_soal')); ?>" style="font-size: 11px;" required>
                            <?php $__errorArgs = ['bobot_soal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>                        

                        <!-- Buttons -->
                        <div class="d-flex justify-content-start mt-3">
                            <button type="submit" class="btn btn-primary" style="font-size: 11px;" title="Save Sementara">
                                <i class="fas fa-save"></i>
                            </button> 
                            <a href="<?php echo e(route('admin.bobot-soal.index')); ?>" class="btn btn-secondary ml-2" style="font-size: 11px;" title="Kembali">
                                <i class="fas fa-arrow-left"></i>
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <?php if(!empty($temporaryData)): ?>
            <div class="card shadow mb-4" style="font-size: 11px;">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary" style="font-size: 11px;">Lihat Form Tambah Bobot</h6>
                </div>
                <div class="card-body">
                    <table class="table table-bordered" style="font-size: 11px;">
                        <thead>
                            <tr>
                                <th>Nama Mata Lomba</th>
                                <th>Kriteria Nilai</th>
                                <th>Bobot</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $temporaryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($mata_lomba->firstWhere('id', $data['mata_lomba_id'])->nama ?? 'N/A'); ?></td>
                                    <td><?php echo e($data['kriteria_nilai']); ?></td>
                                    <td><?php echo e($data['bobot_soal']); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('admin.bobot-soal.removeTemporary', $index)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger" style="font-size: 11px;" title="Hapus">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="2"><strong>Total Bobot</strong></td>
                                <td colspan="2"><?php echo e(array_sum(array_column($temporaryData, 'bobot_soal'))); ?></td>
                            </tr>
                        </tbody>
                    </table>

                    <form action="<?php echo e(route('admin.bobot-soal.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-success" style="font-size: 11px;" title="Simpan Database">
                            <i class="fas fa-save"></i>
                        </button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/admin/bobot_soal/create.blade.php ENDPATH**/ ?>