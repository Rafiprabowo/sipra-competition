<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('h-script'); ?>
    <!-- Pickadate.js CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/pickadate.js/3.6.4/compressed/themes/default.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/pickadate.js/3.6.4/compressed/themes/default.date.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/pickadate.js/3.6.4/compressed/themes/default.time.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container" style="font-size: 11px;">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Edit Sesi Computer Based Test</h6>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('sesi-cbt.update', $session->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                
                    <div class="form-group">
                        <label for="nama">Nama Sesi</label>
                        <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e(old('nama', $session->nama)); ?>" style="font-size: 11px;" required>
                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                
                    <div class="form-group">
                        <label for="mata_lomba_id">Lomba Computer Based Test</label>
                        <select class="form-control" name="mata_lomba_id" id="mata_lomba_id" style="font-size: 11px;" required>
                            <option value="">--Pilih--</option>
                            <?php $__currentLoopData = $mataLombas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $session->mata_lomba_id ? 'selected' : ''); ?>>
                                    <?php echo e($item->nama); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['mata_lomba_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                
                    <div class="form-group">
                        <label for="waktu_mulai">Waktu Mulai</label>
                        <div class="input-group">
                            <input type="text" class="form-control timepicker" id="waktu_mulai" name="waktu_mulai" value="<?php echo e(old('waktu_mulai', $session->waktu_mulai)); ?>" style="font-size: 11px;" required>
                            <div class="input-group-append">
                                <span class="input-group-text"><i class="fa fa-clock"></i></span>
                            </div>
                        </div>
                        <?php $__errorArgs = ['waktu_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="form-group">
                        <label for="waktu_selesai">Waktu Selesai</label>
                        <div class="input-group">
                            <input type="text" class="form-control timepicker" id="waktu_selesai" name="waktu_selesai" value="<?php echo e(old('waktu_selesai', $session->waktu_selesai)); ?>" style="font-size: 11px;" required>
                            <div class="input-group-append">
                                <span class="input-group-text"><i class="fa fa-clock"></i></span>
                            </div>
                        </div>
                        <?php $__errorArgs = ['waktu_selesai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                
                
                    <div class="form-group">
                        <label for="jumlah_soal">Jumlah Soal</label>
                        <input type="number" class="form-control" id="jumlah_soal" name="jumlah_soal" value="<?php echo e(old('jumlah_soal', $session->jumlah_soal)); ?>" style="font-size: 11px;" required>
                        <?php $__errorArgs = ['jumlah_soal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select class="form-control" name="status" id="status" style="font-size: 11px;" required>
                            <option value="<?php echo e(\App\Enums\StatusSesiCbt::Draft->value); ?>" <?php echo e($session->status == \App\Enums\StatusSesiCbt::Draft->value ? 'selected' : ''); ?>>Ditutup</option>
                            <option value="<?php echo e(\App\Enums\StatusSesiCbt::Active->value); ?>" <?php echo e($session->status == \App\Enums\StatusSesiCbt::Active->value ? 'selected' : ''); ?>>Dibuka</option>
                            <option value="<?php echo e(\App\Enums\StatusSesiCbt::Completed->value); ?>" <?php echo e($session->status == \App\Enums\StatusSesiCbt::Completed->value ? 'selected' : ''); ?>>Selesai</option>
                        </select>
                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                
                    <div class="form-group">
                        <label for="kode_akses">Kode Akses (opsional)</label>
                        <input type="text" class="form-control" id="kode_akses" name="kode_akses" value="<?php echo e(old('kode_akses', $session->kode_akses)); ?>" style="font-size: 11px;">
                        <?php $__errorArgs = ['kode_akses'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                
                    <div class="d-flex">
                        <a href="<?php echo e(route('sesi-cbt.index')); ?>" class="btn btn-secondary mr-2" style="font-size: 11px;" title="Kembali">
                            <i class="fas fa-arrow-left"></i>
                        </a>
                        <button type="submit" class="btn btn-primary" style="font-size: 11px;" title="Simpan">
                            <i class="fas fa-save"></i>
                        </button>
                    </div>
                </form>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
 <!-- jQuery -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 <!-- Bootstrap JS -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
 <!-- Pickadate.js JS -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/pickadate.js/3.6.4/compressed/picker.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/pickadate.js/3.6.4/compressed/picker.date.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/pickadate.js/3.6.4/compressed/picker.time.js"></script>
 <script>
    $(document).ready(function(){
        $('#waktu_mulai').pickatime({
            format: 'HH:i'
        });
        $('#waktu_selesai').pickatime({
            format: 'HH:i'
        });
    });
 </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/admin/sesi-cbt/edit.blade.php ENDPATH**/ ?>