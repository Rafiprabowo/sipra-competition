<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid" style="font-size: 11px;">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('simulasi-soal-sms.index')); ?>">SMS Questions</a></li>
                <li class="breadcrumb-item active" aria-current="page">Edit Pertanyaan SMS</li>
            </ol>
        </nav>

        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <h5 style="font-size: 11px;">Edit Pertanyaan SMS</h5>
                <a href="<?php echo e(route('simulasi-soal-sms.index')); ?>" class="btn btn-secondary btn-sm" title="Back to List">
                    <i class="fas fa-arrow-left"></i>
                </a>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('simulasi-soal-sms.update', $simulasiSmsQuestion->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <!-- Jenis Simulasi soal -->
                    <div class="form-group">
                        <label for="type">Jenis</label>
                        <select name="type" id="type" class="form-control form-control-sm" required>
                            <option value="<?php echo e(\App\Enums\QuestionType::SEMAPHORE->value); ?>" 
                                    <?php echo e(old('type', $simulasiSmsQuestion->type) == \App\Enums\QuestionType::SEMAPHORE->value ? 'selected' : ''); ?>>
                                Semaphore
                            </option>
                            <option value="<?php echo e(\App\Enums\QuestionType::MORSE->value); ?>" 
                                    <?php echo e(old('type', $simulasiSmsQuestion->type) == \App\Enums\QuestionType::MORSE->value ? 'selected' : ''); ?>>
                                Morse
                            </option>
                        </select>
                        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Kata -->
                    <div class="form-group">
                        <label for="word">Kata</label>
                        <input type="text" name="word" id="word" class="form-control form-control-sm" 
                               value="<?php echo e(old('word', $simulasiSmsQuestion->word)); ?>" required>
                        <?php $__errorArgs = ['word'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Tingkat Kesulitan -->
                    <div class="form-group">
                        <label for="difficulty">Tingkat Kesulitan</label>
                        <select name="difficulty" id="difficulty" class="form-control form-control-sm" required>
                            <option value="mudah" <?php echo e(old('difficulty', $simulasiSmsQuestion->difficulty) == 'mudah' ? 'selected' : ''); ?>>Mudah</option>
                            <option value="sulit" <?php echo e(old('difficulty', $simulasiSmsQuestion->difficulty) == 'sulit' ? 'selected' : ''); ?>>Sulit</option>
                        </select>
                        <?php $__errorArgs = ['difficulty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <button type="submit" class="btn btn-primary btn-sm" style="font-size: 11px;">Simpan Perubahan</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/admin/bank-soal/simulasi_sms/edit.blade.php ENDPATH**/ ?>