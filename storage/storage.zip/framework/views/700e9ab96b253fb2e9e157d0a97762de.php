<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.pembina', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="col-sm-12 ms-2 me-2 mt-4" style="font-size: 11px;">
    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert"> <?php echo e(session('success')); ?> </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert"> <?php echo e(session('error')); ?> </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="card shadow mb-4" style="font-size: 10px;">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary" style="font-size: 11px;">List Status Validasi Persyaratan Lomba</h6>
        </div>

        <div class="card-body">
            <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" style="text-align: center">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Pembina</th>
            <th>Pangkalan</th>
            <th>Dokumen dan Status</th>
            <th>Status Finalisasi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $finalisasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $finalisasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($finalisasi->pembina->nama); ?></td>
                <td><?php echo e($finalisasi->pembina->pangkalan); ?></td>
                <td>
                    <ul class="list-group">
                        <?php $__empty_1 = true; $__currentLoopData = $finalisasi->pembina->upload_dokumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div class="d-flex align-items-center">
                                    <div>
                                        <?php echo e($doc->template_dokumen->nama); ?>

                                    </div>
                                    <span class="badge ml-2 <?php echo e($doc->status == 1 ? 'badge-success' : ($doc->status == 0 ? 'badge-danger' : 'badge-warning')); ?>">
                                        <?php echo e($doc->status == 1 ? 'Tervalidasi' : ($doc->status == 0 ? 'Tidak Tervalidasi' : 'Menunggu Verifikasi')); ?>

                                    </span>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li class="list-group-item text-center">
                                Tidak ada data.
                            </li>
                        <?php endif; ?>
                    </ul>
                    
                </td>
                <td>
                    <?php if($finalisasi && $finalisasi->status == 1): ?>
                        <span class="badge badge-success">Lolos Verifikasi</span>
                    <?php elseif($finalisasi && $finalisasi->status === 0): ?>
                        <span class="badge badge-danger">Tidak Lolos Verifikasi</span>
                    <?php else: ?>
                        <span class="badge badge-warning">Menunggu Verifikasi</span>
                    <?php endif; ?>
                </td>
            
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="6" class="text-center">
                <i class="fas fa-info-circle text-warning"></i> <strong>Pemberitahuan:</strong> Data Pangkalan yang belum lolos validasi tolong mengecek kelengkapan registrasi lomba oleh Pembina masing-masing.
            </td>
        </tr>
    </tfoot>
</table>

  </div>
        </div>
    </div>
  </div>

  <script>
    document.addEventListener("DOMContentLoaded", function() {
        $('#dataTable').DataTable({
            pageLength: 10, // Set number of rows per page
            responsive: true,
            searching: true,
            ordering: true
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/pembina/dashboard.blade.php ENDPATH**/ ?>