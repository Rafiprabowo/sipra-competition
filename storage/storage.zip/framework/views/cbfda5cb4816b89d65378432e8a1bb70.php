<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.juri', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container" style="font-size: 11px;">
        <form method="POST" action="<?php echo e(route('juri.profil_juri')); ?>">
            <?php echo csrf_field(); ?>
            <h3 style="font-size: 11px;">Data Profil Juri :</h3>
    
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
    
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
    
            <div class="form-group">
                <label for="nama">Nama</label>
                <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e($juri->nama ?? ''); ?>" style="font-size: 11px;">
            </div>
            <div class="form-group">
                <label for="alamat">Alamat</label>
                <input type="text" class="form-control" id="alamat" name="alamat" value="<?php echo e($juri->alamat ?? ''); ?>" style="font-size: 11px;">
            </div>
            <div class="form-group">
                <label for="tanggal_lahir">Tanggal Lahir</label>
                <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir" value="<?php echo e($juri->tanggal_lahir ?? ''); ?>" style="font-size: 11px;">
            </div>
            <div class="form-group">
                <label for="jenis_kelamin">Jenis Kelamin</label>
                <select class="form-control" id="jenis_kelamin" name="jenis_kelamin" style="font-size: 11px;">
                    <option value="L" <?php echo e((isset($juri->jenis_kelamin) && $juri->jenis_kelamin == 'L') ? 'selected' : ''); ?>>Laki-laki</option>
                    <option value="P" <?php echo e((isset($juri->jenis_kelamin) && $juri->jenis_kelamin == 'P') ? 'selected' : ''); ?>>Perempuan</option>
                </select>
            </div>
            <div class="form-group">
                <label for="no_hp">Nomor Handphone</label>
                <input type="text" class="form-control" id="no_hp" name="no_hp" value="<?php echo e($juri->no_hp ?? ''); ?>" style="font-size: 11px;">
            </div>
            <div class="form-group">
                <label for="kwartir_cabang">Kwartir Cabang</label>
                <input type="text" class="form-control" id="kwartir_cabang" name="kwartir_cabang" value="<?php echo e($juri->kwartir_cabang ?? ''); ?>" style="font-size: 11px;">
            </div>
            <div class="form-group">
                <label for="pangkalan">Nama Pangkalan</label>
                <input type="text" class="form-control" id="pangkalan" name="pangkalan" value="<?php echo e($juri->pangkalan ?? ''); ?>" style="font-size: 11px;">
            </div>
            <div class="form-group">
                <label for="pengalaman_juri">Pengalaman Juri</label>
                <input type="text" class="form-control" id="pengalaman_juri" name="pengalaman_juri" value="<?php echo e($juri->pengalaman_juri ?? ''); ?>" style="font-size: 11px;">
            </div>
            <div class="form-group">
                <label for="pekerjaan">Pekerjaan</label>
                <input type="text" class="form-control" id="pekerjaan" name="pekerjaan" value="<?php echo e($juri->pekerjaan ?? ''); ?>" style="font-size: 11px;">
            </div>
            <button type="submit" class="btn btn-primary" style="font-size: 11px;">Simpan</button>
        </form>

        <?php if(isset($juri)): ?>
        <div class="mt-5">
            <table class="table table-bordered">
                <tbody>
                    <tr>
                        <td><strong>Nama</strong></td>
                        <td><?php echo e($juri->nama); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Alamat</strong></td>
                        <td><?php echo e($juri->alamat); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Tanggal Lahir</strong></td>
                        <td><?php echo e($juri->tanggal_lahir); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Jenis Kelamin</strong></td>
                        <td><?php echo e($juri->jenis_kelamin); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Nomor Handphone</strong></td>
                        <td><?php echo e($juri->no_hp); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Kwartir Cabang</strong></td>
                        <td><?php echo e($juri->kwartir_cabang); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Nama Pangkalan</strong></td>
                        <td><?php echo e($juri->pangkalan); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Pengalaman Juri</strong></td>
                        <td><?php echo e($juri->pengalaman_juri); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Pekerjaan</strong></td>
                        <td><?php echo e($juri->pekerjaan); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Mata Lomba</strong></td>
                        <td><?php echo e(optional($juri->mata_lomba)->nama ?? 'Belum Diisi'); ?></td>
                
                    </tr>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/juri/profil_juri.blade.php ENDPATH**/ ?>