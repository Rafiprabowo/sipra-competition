<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid" style="font-size: 11px;">
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <?php if(empty($rankingResults['ranked_participants'])): ?>
            <div class="alert alert-info" role="alert">
                Tidak ada data peserta yang tersedia saat ini.
            </div>
        <?php else: ?>
            <div class="card shadow">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary" style="font-size: 16px;">Hasil Lomba Tes Pengetahuan Kepramukaan</h6>
                    <div class="d-flex justify-content-end">
                        <a href="<?php echo e(route('pdf.lomba-tpk')); ?>" class="btn btn-primary mt-4 mr-2" style="font-size: 11px;">
                            <i class="fas fa-file-pdf"></i> Ekspor PDF
                        </a>
                        <a href="<?php echo e(route('excel.lomba-tpk')); ?>" class="btn btn-success mt-4" style="font-size: 11px;">
                            <i class="fas fa-file-excel"></i> Ekspor Excel
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <table id="table-participants" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Peserta</th>
                                <th>Pangkalan</th>
                                <th>Regu</th>
                                <th>Nilai</th>
                                <th>Jenis Kelamin</th>
                                <th>Juara</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $allParticipants = collect();
                                foreach ($rankingResults['ranked_participants'] as $gender => $participants) {
                                    $allParticipants = $allParticipants->merge($participants);
                                }
                            ?>

                            <?php $__currentLoopData = $allParticipants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($participant->peserta->nama ?? 'N/A'); ?></td>
                                    <td><?php echo e($participant->peserta->regu_pembina->pembina->pangkalan ?? 'N/A'); ?></td>
                                    <td><?php echo e($participant->peserta->regu_pembina->nama_regu ?? 'N/A'); ?></td>
                                    <td><?php echo e($participant->score); ?></td>
                                    <td><?php echo e($participant->peserta->jenis_kelamin); ?></td>
                                    <td><?php echo e($participant->rank ? 'Juara ' . $participant->rank : '-'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <div class="d-flex justify-content-start mt-4">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-secondary" style="font-size: 11px;" title="Kembali">
                <i class="fas fa-arrow-left"></i>
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            $('#table-participants').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/hasil-lomba-tpk.blade.php ENDPATH**/ ?>