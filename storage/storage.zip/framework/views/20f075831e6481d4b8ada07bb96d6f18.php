<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.juri', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container" style="font-size: 11px;">
    <h2 style="font-size: 11px;">Edit Profile</h2>
    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>
    <form action="<?php echo e(route('updateProfileJuri')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" class="form-control" id="username" name="username" value="<?php echo e($user->username); ?>" style="font-size: 11px;" required>
        </div>
        <div class="form-group">
            <label for="nama">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e($juri->nama); ?>" style="font-size: 11px;" required>
        </div>
        <div class="form-group">
            <label for="password">New Password</label>
            <input type="password" class="form-control" id="password" name="password" style="font-size: 11px;">
        </div>
        <div class="form-group">
            <label for="password_confirmation">Confirm New Password</label>
            <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" style="font-size: 11px;">
        </div>
        <div class="form-group">
            <label for="foto_profil">Profile Picture</label>
            <input type="file" class="form-control" id="foto_profil" name="foto_profil" style="font-size: 11px;">
        </div>
        <button type="submit" class="btn btn-primary mr-2" style="font-size: 11px;" title="Update">
            <i class="fas fa-sync-alt"></i>
        </button>
        <a href="<?php echo e(route(auth()->user()->role . '.dashboard')); ?>" class="btn btn-secondary ml-2" style="font-size: 11px;" title="Kembali">
            <i class="fas fa-arrow-left"></i>
        </a>
    </form>
</div>

<script>
    function validatePasswords() {
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('password_confirmation').value;

        if (password !== confirmPassword) {
            alert('Confirm Password harus sama dengan New Password!');
            return false;
        }
        return true;
    }
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/juri/editProfile-juri.blade.php ENDPATH**/ ?>