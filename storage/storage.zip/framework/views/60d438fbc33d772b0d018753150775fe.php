<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('layouts.sidebar.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-sm-12 ms-2 me-2" style="font-size: 11px;">
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert">
            <p><?php echo e(session('error')); ?></p>
            <button onclick="window.location='<?php echo e(route('admin.dashboard')); ?>'" class="btn btn-primary">OK</button>
        </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="card shadow">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-primary" style="font-size: 16px;">Lihat Hasil Penilaian Pionering</h6>
                <ul class="nav nav-tabs">
                    <li class="nav-item">
                        <a class="nav-link active" id="putra-tab" data-toggle="tab" href="#putra" role="tab" aria-controls="putra" aria-selected="true">Putra</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="putri-tab" data-toggle="tab" href="#putri" role="tab" aria-controls="putri" aria-selected="false">Putri</a>
                    </li>
                </ul>
                <!-- Tombol Ekspor -->
                <div>
                    <a href="<?php echo e(route('exportPDF', ['tab' => 'putra'])); ?>" class="btn btn-danger btn-md" title="Export PDF Putra" style="font-size: 11px;">
                        <i class="fas fa-file-pdf"></i> Export PDF Putra
                    </a>
                    <a href="<?php echo e(route('exportPDF', ['tab' => 'putri'])); ?>" class="btn btn-warning btn-md" title="Export PDF Putri" style="font-size: 11px;">
                        <i class="fas fa-file-pdf"></i> Export PDF Putri
                    </a>
                    <a href="<?php echo e(route('exportExcel')); ?>" class="btn btn-success btn-md" title="Export Excel" style="font-size: 11px;">
                        <i class="fas fa-file-excel"></i> Export Excel
                    </a>
                </div>
            </div>

            <div class="card-body">
                <div class="tab-content">
                    <!-- Putra Tab -->
                    <div class="tab-pane fade show active" id="putra" role="tabpanel" aria-labelledby="putra-tab">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTablePutra" width="100%" cellspacing="0" style="text-align: center;">
                                <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Peserta</th>
                                    <th>Regu</th>
                                    <th>Pangkalan</th>
                                    <th>Jenis Kelamin</th>
                                    <th>Nilai akhir</th>
                                    <th>Rangking</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $putra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($peserta->nama); ?></td>
                                        <td><?php echo e($peserta->regu_pembina->nama_regu); ?></td>
                                        <td><?php echo e($peserta->regu_pembina->pembina->pangkalan); ?></td>
                                        <td><?php echo e($peserta->jenis_kelamin); ?></td>
                                        <td><?php echo e($peserta->highest_total_nilai); ?></td>
                                        <td><?php echo e($peserta->penilaian_pionering->rangking); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- Putri Tab -->
                    <div class="tab-pane fade" id="putri" role="tabpanel" aria-labelledby="putri-tab">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTablePutri" width="100%" cellspacing="0" style="text-align: center;">
                                <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama</th>
                                    <th>Nama Regu</th>
                                    <th>Pangkalan</th>
                                    <th>Jenis Kelamin</th>
                                    <th>Nilai akhir</th>
                                    <th>Rangking</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $putri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $peserta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($peserta->nama); ?></td>
                                        <td><?php echo e($peserta->regu_pembina->nama_regu); ?></td>
                                        <td><?php echo e($peserta->regu_pembina->pembina->pangkalan); ?></td>
                                        <td><?php echo e($peserta->jenis_kelamin); ?></td>
                                        <td><?php echo e($peserta->highest_total_nilai); ?></td>
                                        <td><?php echo e($peserta->penilaian_pionering->rangking); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            $('#dataTablePutra').DataTable({
                pageLength: 10, // Set number of rows per page
                responsive: true,
                searching: true,
                ordering: true,
            });
            $('#dataTablePutri').DataTable({
                pageLength: 10, // Set number of rows per page
                responsive: true,
                searching: true,
                ordering: true,
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipra-competition\resources\views/admin/hasil_nilai/nilai_pionering.blade.php ENDPATH**/ ?>